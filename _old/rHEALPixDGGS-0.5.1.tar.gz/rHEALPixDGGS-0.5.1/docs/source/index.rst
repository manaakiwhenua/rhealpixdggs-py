.. scenzgrid-dggs documentation master file.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome the rHEALPixDGGS documentation!
===========================================

.. toctree::
   :maxdepth: 2

   introduction
   utils
   pj_healpix
   pj_rhealpix
   ellipsoids
   projection_wrapper
   dggs
   distortion
  
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

