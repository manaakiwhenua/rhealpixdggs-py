The ellipsoids Module
===========================

.. automodule:: rhealpix_dggs.ellipsoids
    :members:
    :undoc-members:
    :show-inheritance:
