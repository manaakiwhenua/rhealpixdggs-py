- v0.5, 2013-07-26: Port to Python 3.3.

