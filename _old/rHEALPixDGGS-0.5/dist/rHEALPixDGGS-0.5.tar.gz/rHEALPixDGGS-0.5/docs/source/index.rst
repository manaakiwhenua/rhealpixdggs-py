.. scenzgrid-dggs documentation master file.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to scenzgrid-dggs's documentation!
===========================================

.. toctree::
   :maxdepth: 2

   introduction
   projection_tools
   pj_healpix
   pj_rhealpix
   ellipsoids
   projection_wrapper
   rhealpix_dggs
   distortion
  
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

