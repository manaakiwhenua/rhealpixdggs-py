The ellipsoids Module
===========================

.. automodule:: ellipsoids
    :members:
    :undoc-members:
    :show-inheritance:
